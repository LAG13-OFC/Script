# SCOTT PRO ⚡

# @SCOTTSSH

*PROJETO EM BETA🍷🗿
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/ScottBrabo/PR0/main/ssh-plus)

```
